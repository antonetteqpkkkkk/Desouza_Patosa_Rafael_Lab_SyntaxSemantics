"""
CS413 - Laboratory Activity No. 2
"From Syntax to Semantics: Building a Grammar Checker and Evaluator"

Grammar implemented (EBNF form, used because it removes left recursion
and maps directly onto loops):

    <expr>   -> <term> { (+ | -) <term> }
    <term>   -> <factor> { (* | /) <factor> }
    <factor> -> ( <expr> ) | <digit>
    <digit>  -> 0|1|2|3|4|5|6|7|8|9

Design notes
------------
Task A (syntax) and Task B (semantics) are kept as two separate passes,
on purpose, so the difference between "is this well-formed?" and
"what does it mean?" is visible in the code, not just in words:

  1. parse_expr / parse_term / parse_factor  -> build an AST (Task A).
     They ONLY check grammar rules. They never compute a value.
     If the string does not match the grammar, they raise ParseError
     with the position and the offending token.

  2. evaluate(ast)  -> walks the AST and computes the number (Task B).
     It is only ever called after parsing succeeds, so semantic
     evaluation is strictly downstream of, and depends on, a
     successful syntax check.
"""


class ParseError(Exception):
    """Raised by the parser when the input does not match the grammar."""
    def __init__(self, message, position):
        self.message = message
        self.position = position
        super().__init__(message)


class Parser:
    """
    Recursive-descent parser for the EBNF grammar above.

    self.text -> the raw input string (whitespace already stripped out)
    self.pos  -> index of the next character the parser has not consumed yet

    Every parse_xxx method corresponds to exactly one grammar rule,
    which is exactly what a recursive-descent parser is supposed to be:
    grammar rules translated 1-to-1 into functions.
    """

    def __init__(self, text):
        self.text = text
        self.pos = 0

    # ---------- small helpers ----------

    def peek(self):
        """Return the current character without consuming it, or None at end."""
        if self.pos < len(self.text):
            return self.text[self.pos]
        return None

    def error(self, message):
        token = self.peek() if self.peek() is not None else "end of input"
        raise ParseError(f"{message} (found '{token}' at position {self.pos})", self.pos)

    # ---------- grammar rules ----------

    def parse_expr(self):
        """
        <expr> -> <term> { (+ | -) <term> }

        Loop = the { ... } repetition in the EBNF.
        Building the AST as ('op', left_so_far, next_term) inside the
        loop, instead of recursing, is exactly what gives us
        LEFT-associativity: 8-3-2 becomes (8-3)-2, not 8-(3-2).
        """
        node = self.parse_term()
        while self.peek() in ('+', '-'):
            op = self.peek()
            self.pos += 1
            right = self.parse_term()
            node = (op, node, right)
        return node

    def parse_term(self):
        """
        <term> -> <factor> { (* | /) <factor> }

        Same left-associative loop pattern as parse_expr, but for
        * and /. Because parse_term is called *inside* parse_expr
        (via parse_factor -> ... -> parse_term), multiplication and
        division always get bound before addition and subtraction.
        That is precedence, built from the shape of the grammar, not
        from any special-cased priority rule in the code.
        """
        node = self.parse_factor()
        while self.peek() in ('*', '/'):
            op = self.peek()
            self.pos += 1
            right = self.parse_factor()
            node = (op, node, right)
        return node

    def parse_factor(self):
        """
        <factor> -> ( <expr> ) | <digit>

        This is where the grammar's only recursion lives: to parse a
        factor that starts with '(', parse_factor calls back into
        parse_expr, which may itself contain factors, which may
        contain more parentheses, and so on.
        """
        ch = self.peek()

        if ch == '(':
            self.pos += 1               # consume '('
            node = self.parse_expr()    # <-- RECURSION: factor -> ( expr )
            if self.peek() != ')':
                self.error("Expected ')'")
            self.pos += 1                # consume ')'
            return node

        if ch is not None and ch.isdigit():
            self.pos += 1
            return ('num', int(ch))

        self.error("Expected a digit or '('")


def parse(expression):
    """
    Task A - Syntax Check.

    Returns an AST if `expression` is a valid sentence of the grammar.
    Raises ParseError (with position/token) if it is not, including
    the case where parsing finishes early but characters are left
    over (e.g. "3+4)"), which is a REJECT case the activity calls out
    explicitly.
    """
    cleaned = expression.replace(" ", "")
    if cleaned == "":
        raise ParseError("Empty expression", 0)

    parser = Parser(cleaned)
    ast = parser.parse_expr()

    if parser.pos != len(cleaned):
        # Successfully parsed a valid expression, but extra characters
        # remain afterwards -> still a REJECT ("leftover input").
        parser.error("Unexpected extra input after a valid expression")

    return ast


def evaluate(node):
    """
    Task B - Semantic Evaluation.

    Walks the AST produced by parse() and computes its numeric value.
    Only ever called on an AST that has already passed Task A.

    Division note: Python's normal '/' always returns a float
    (e.g. 8/2 -> 4.0), which is the honest, non-truncating behavior
    and is what the grammar's '/' means here. We deliberately do NOT
    use '//' (integer division), since nothing in the activity asks
    for truncation, and using '//' would silently change the meaning
    of division for cases like 3/2. To match the activity's expected
    output format (e.g. 8/2-1 -> 3, not 3.0), whole-number results are
    displayed without a trailing ".0" -- see format_value() below.
    This is a display choice only; the arithmetic itself is float.
    """
    if node[0] == 'num':
        return node[1]

    op, left, right = node
    left_val = evaluate(left)
    right_val = evaluate(right)

    if op == '+':
        return left_val + right_val
    elif op == '-':
        return left_val - right_val
    elif op == '*':
        return left_val * right_val
    elif op == '/':
        return left_val / right_val


def format_value(value):
    """Print 3.0 as '3', but keep 1.5 as '1.5'."""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value)


def check_and_evaluate(expression, verbose=True):
    """
    Runs Task A, then Task B if Task A succeeds.
    Returns (is_valid, result_or_error_message).
    """
    try:
        ast = parse(expression)
    except ParseError as e:
        if verbose:
            print(f"Input: {expression!r:>10}  ->  Invalid syntax: {e.message}")
        return False, e.message

    value = evaluate(ast)
    if verbose:
        print(f"Input: {expression!r:>10}  ->  Valid syntax, Value = {format_value(value)}")
    return True, value


# ---------------------------------------------------------------------
# STRETCH REQUIREMENT - "the villain": the ambiguous grammar
#
#   <expr> -> <expr> + <expr> | <expr> * <expr> | <digit>
#
# This grammar gives NO rule for which operator binds first, so two
# different (both "legal") ways of grouping the same string give two
# different answers. We simulate that here with a naive left-to-right
# evaluator that has no concept of precedence at all.
# ---------------------------------------------------------------------

def naive_left_to_right_eval(expression):
    """
    Evaluates strictly left to right, ignoring precedence entirely,
    to demonstrate what the AMBIGUOUS grammar allows: 2+3*4 read as
    ((2+3)*4).
    """
    cleaned = expression.replace(" ", "")
    tokens = list(cleaned)
    value = int(tokens[0])
    i = 1
    while i < len(tokens):
        op = tokens[i]
        digit = int(tokens[i + 1])
        if op == '+':
            value = value + digit
        elif op == '*':
            value = value * digit
        i += 2
    return value


def demonstrate_ambiguity(expression="2+3*4"):
    naive_result = naive_left_to_right_eval(expression)   # 2+3=5, 5*4=20
    _, correct_result = check_and_evaluate(expression, verbose=False)  # 3*4=12, 2+12=14

    print(f"Ambiguous grammar demonstration for '{expression}':")
    print(f"  Left-to-right reading (no precedence): {naive_result}")
    print(f"  Correct grammar (precedence + assoc.) : {format_value(correct_result)}")
    print("  -> Same input string, two different 'meanings'. That is exactly")
    print("     what an ambiguous grammar produces, which is why Section II's")
    print("     grammar puts <term> BELOW <expr>: it forces * and / to bind")
    print("     to their digits before + and - are applied, so 2+3*4 can only")
    print("     ever mean 2+(3*4), never (2+3)*4.")


# ---------------------------------------------------------------------
# MAIN - required + additional test cases
# ---------------------------------------------------------------------

if __name__ == "__main__":
    print("=" * 60)
    print("STRETCH REQUIREMENT - Ambiguous grammar, before the fix")
    print("=" * 60)
    demonstrate_ambiguity("2+3*4")

    print()
    print("=" * 60)
    print("REQUIRED TEST CASES (Section V of the activity)")
    print("=" * 60)
    required_cases = ["3+4*2", "(3+4)*2", "8/2-1", "3++4", "(3+4", "2+3*4"]
    for case in required_cases:
        check_and_evaluate(case)

    print()
    print("=" * 60)
    print("ADDITIONAL TEST CASES (not required, added to show robustness)")
    print("=" * 60)
    additional_valid = ["1+2", "9*8", "9/3", "1+2*3", "(1+2)*3",
                         "8-3-2", "8/(2+2)", "((2+3)*4)"]
    additional_invalid = ["3+", "*3", "3**4", "(3+4", "3+4)", "()", "3(4+5)", "a+3"]

    print("-- valid inputs --")
    for case in additional_valid:
        check_and_evaluate(case)

    print("-- invalid inputs --")
    for case in additional_invalid:
        check_and_evaluate(case)
